package com.course;

import lombok.extern.slf4j.Slf4j;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * @author chao.cheng
 * @createTime 2020/4/25 6:20 下午
 * @description
 **/
@Slf4j
//@Service
public class EhcacheDemo {

    private static CacheManager cacheManager;

    static {
        //默认读取classpath目录下面的ehcache.xml
        String path = EhcacheDemo.class.getResource("/").toString() +"/ehcache.xml";
        String[] tmp = path.split("\\:");
        cacheManager = new CacheManager(tmp[1]);
    }

    public void init() {

        // 2.创建Cachelogback-spring.xml
        cacheManager.addCacheIfAbsent("cache_test");
        Cache cache = cacheManager.getCache("cache_test");

        // 3.存取元素
        cache.put(new Element("firstCache", "第一个缓存元素"));

        // 4.获取元素
        Element element = cache.get("firstCache");
        log.info("获取的缓存元素是:{}", element);
        long creationTime = element.getCreationTime();
        long expirationTime = element.getExpirationTime();
        log.info("creationTime： {}", new Date(creationTime));
        log.info("expirationTime： {}", new Date(expirationTime));

        int diskStoreSize = cache.getDiskStoreSize();
        int cacheSize = cache.getKeys().size();
        log.info("diskStoreSize:{}", diskStoreSize);
        log.info("cacheSize： {}", cacheSize);
    }


}
