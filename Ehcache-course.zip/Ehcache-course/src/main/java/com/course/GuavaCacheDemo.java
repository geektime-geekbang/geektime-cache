package com.course;

import com.google.common.cache.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

/**
 * @author chao.cheng
 * @createTime 2020/4/25 11:30 下午
 * @description
 **/
@Slf4j
@Service
public class GuavaCacheDemo {

    private static LoadingCache<String, String> cache = CacheBuilder.newBuilder()
            //设置大小，条目数
            .maximumSize(20)
            //设置失效时间，创建时间
            .expireAfterWrite(20, TimeUnit.SECONDS)
            //设置时效时间，最后一次被访问
            .expireAfterAccess(20, TimeUnit.HOURS)
            //移除缓存的监听器
            .removalListener(new RemovalListener<String, String>() {
                @Override
                public void onRemoval(RemovalNotification<String, String> notification) {
                    log.info("有缓存数据被移除了:" + notification.getKey() + "=" + notification.getValue());
                }
            })
            //缓存构建的回调
            .build(new CacheLoader<String, String>() {//加载缓存
                @Override
                public String load(String key) throws Exception {
                    log.info("缓存中...key:" + key);
                    return "test" + "_" + key;
                }
            });

    /**
     * 获取缓存值
     * 注：如果键不存在值，将调用CacheLoader的load方法加载新值到该键中
     *
     * @param key
     * @return
     */
    public static String get(String key) {
        try {
            String value = cache.get(key);
            log.info("get值是:" + value);
            return value;
        } catch (Exception e) {
            log.error("put cache data is error! key:" + key, e);
        }
        return null;
    }

    /**
     * 移除缓存
     *
     * @param key
     */
    public static void remove(Long key) {
        try {
            cache.invalidate(key);
        } catch (Exception e) {
            log.error("移除缓存出错", e);
        }
    }

    /**
     * 清空缓存内数据
     * 操作基础数据时，清除重新查询
     */
    public static void clearAll() {
        //全部清除缓存
        cache.invalidateAll();
    }

    /**
     * 设置缓存值
     * 注: 若已有该key值，则会先移除(会触发removalListener移除监听器)，再添加
     *
     * @param key
     * @param value
     */
    public static void put(String key, String value) {
        cache.put(key, value);
        log.info("put成功 key:" + key + " , " + "value:" + value);
    }

    /**
     * 查看缓存中内容
     */
    public static ConcurrentMap<String, String> viewCache() {
        //查看内容
        log.info("查看内容:" + cache.asMap());
        return cache.asMap();
    }

    public static void main(String[] args) throws Exception {
        put("abc", "abc");
        log.info(get("cache1"));
        log.info(get("cache2"));
        System.out.println(viewCache());
        clearAll();
    }


}
