package com.course;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

/**
 * @author chao.cheng
 * @createTime 2020/4/25 8:27 下午
 * @description
 **/
@SpringBootApplication(scanBasePackages = "com.course")
@EnableCaching
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);

        // ehcache demo
     //   EhcacheDemo demo = (EhcacheDemo) SpringApplication.run(Application.class, args).getBean("ehcacheDemo");
      //  demo.init();



       /*
      // guava cache demo
        GuavaCacheDemo demo = (GuavaCacheDemo)SpringApplication.run(Application.class, args).getBean("guavaCacheDemo");
        GuavaCacheDemo.put("abc","abc");
        GuavaCacheDemo.get("cache1");
        GuavaCacheDemo.get("cache2");
        GuavaCacheDemo.clearAll();
        */


    }
}
