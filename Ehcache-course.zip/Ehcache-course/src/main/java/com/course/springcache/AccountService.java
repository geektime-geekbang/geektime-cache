package com.course.springcache;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;


/**
 * @author chao.cheng
 * @createTime 2020/4/28 8:45 上午
 * @description
 **/
@Service
@Slf4j
public class AccountService {

    @Cacheable(value="accountCache")
    public Account getAccountByName(String accountName) throws Exception {

        log.info("走到这里了吗？");
        // 方法内部实现不考虑缓存逻辑，直接实现业务
        log.info("real querying account... {}", accountName);
        Account account =  getFromDB(accountName);
        if(account != null) {
            return account;
        } else {
            throw new Exception("Account is null");
        }
    }

    public Account getFromDB(String accountName) {
        log.info("从数据库中获取数据返回");
        return  new Account(accountName);
    }

    @CachePut(value = "accountCache", key = "#accountName")
    public void saveAccountByName(String accountName) {
        log.info("accountName:"+accountName);
    }


}
