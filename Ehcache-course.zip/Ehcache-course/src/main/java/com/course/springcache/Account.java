package com.course.springcache;

import lombok.Getter;
import lombok.Setter;

/**
 * @author chao.cheng
 * @createTime 2020/4/28 8:42 上午
 * @description
 **/
@Getter
@Setter
public class Account {

    private int id;
    private String name;

    public Account(String name) {
        this.name = name;
    }

}
