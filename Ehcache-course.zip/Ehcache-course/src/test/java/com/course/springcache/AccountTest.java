package com.course.springcache;

import com.course.Application;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author chao.cheng
 * @createTime 2020/4/28 8:59 上午
 * @description
 **/
@RunWith(SpringRunner.class)
@SpringBootTest(classes={Application.class})// 指定启动类
public class AccountTest {

    @Autowired
    private AccountService service;

    @Test
    public void test() throws Exception {
      //  service.saveAccountByName("hello world");
        service.getAccountByName("hello world");
        System.out.println("=====");
        service.getAccountByName("hello world");
        System.out.println("-----");
    }
}
