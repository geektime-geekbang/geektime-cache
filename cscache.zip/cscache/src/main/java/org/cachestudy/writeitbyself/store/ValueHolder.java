package org.cachestudy.writeitbyself.store;

public interface ValueHolder<V> {
	V value();
}
