package com;

import com.guavacache.GuavaCacheDemo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

/**
 * @author chao.cheng
 * @createTime 2020/5/9 11:11 上午
 * @description
 **/
@SpringBootApplication(scanBasePackages = "com")
@EnableCaching
public class Application {
    public static void main(String[] args) {
        GuavaCacheDemo demo = (GuavaCacheDemo)SpringApplication.run(Application.class, args).getBean("guavaCacheDemo");
        GuavaCacheDemo.put("abc", "abcvalue");

        GuavaCacheDemo.get("abc");

        GuavaCacheDemo.remove("abc");
    }
}
