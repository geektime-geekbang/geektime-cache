package com.ehcache;

import lombok.extern.slf4j.Slf4j;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import org.springframework.stereotype.Service;

/**
 * @author chao.cheng
 * @createTime 2020/5/9 10:57 上午
 * @description
 **/
@Slf4j
//@Service
public class EhcacheDemo {

    private static CacheManager cacheManager;

    static {
        String path = EhcacheDemo.class.getResource("/").toString() + "/ehcache.xml";
        String[] tmp = path.split("\\:");
        cacheManager = new CacheManager(tmp[1]);
    }

    public void print() {
        cacheManager.addCacheIfAbsent("cache_test");
        Cache cache = cacheManager.getCache("cache_test");

        cache.put(new Element("firstCode", "第一个元素"));
        Element element = cache.get("firstCode");

        log.info("获取到的元素是:" + element);

        int diskStoreSize = cache.getDiskStoreSize();
        log.info("diskStoreSize:"+diskStoreSize);

    }
}
